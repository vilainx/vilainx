from Mix import get_cgr

__modles__ = "Group"
__help__ = get_cgr("help_group")
