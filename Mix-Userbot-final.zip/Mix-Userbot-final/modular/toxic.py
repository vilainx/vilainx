################################################################
"""
 Mix-Userbot Open Source . Maintained ? Yes Oh No Oh Yes Ngentot
 
 @ CREDIT : NAN-DEV
"""
################################################################

from Mix import *

__modles__ = "Toxic"
__help__ = "Toxic"


@ky.ubot("a")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**ANAK KONTOL, MUKA KEK JEMBUT MASIH MAEN TELE ?**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("b")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**BAJINGAN!! KEREN LOE GITU ? CUIH ANAK HASIL CLONE BELAGU**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("c")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**CEBOK LAH DEK MINIMAL SEBELUM TYPING!!**", reply_to_message_id=ReplyCheck(m)
    )
    await m.delete()


@ky.ubot("d")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**DARI KEMAREN GW LIATIN MUKA LU KAGA BENER-BENER!! KEBENGKEL LAS DULU SONO. TAMBEL ITU MUKA LOE YANH BOPAK**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("e")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**EALAH INI TOH PETINGGI TELE ? JUJURLY MUKA LU KEK JAMET PASAR SENEN BANG. MENDING LOE NGADUK SEMEN!!**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("f")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**FANTAT LOE BURIK YA ? SOALNYA MUKA LU KEREMIAN!!**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("g")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**GOBLOK DIPIARA!! MEMEG NOH LOE PIARA BIAR BANYAK ANAK!!**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("h")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**HAHAHAHA KOK DIEM ? BINGUNG YA LOE BACOT APAAN**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("i")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**IDIH NAJIS BET PESAN GW DIREP AMA BOCAH KEK LOE**",
        reply_to_message_id=ReplyCheck(m),
    )
    await m.delete()


@ky.ubot("j")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**JEMBUT LOE DAH DICUCI BELOM SI ? KOK BAU JEMBUT INI YA??**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("k")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**KALO TYPING YANG BENER DEK!! POTRET BOCAH KAGA PERNAH MAKAN PAPAN TULIS SEKOLAH AN**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("l")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**LAGI NGAPA BAE SI BOCAH ?? ETT DAH GW BANTING, GW GEDIK, GW BANDUT MATI LOE!!**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("m")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**MEMEG EMA LO BURIK YA ? MUKA LO ITU KAYA DAKI MULU KAYA PINGGIRAN PANTAT BANYAK TAI KERING**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("n")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**NETE DULU SONO BARU NGEBACOT, LAA BOCAH NGOMONG KEK SAMBIL MAKAN PASIR. MANA TAI KUCING MULU!!**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("o")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**OHHH INI ORANG NYA? YANG SUKA NYOLONG ? PENGAMGGURAN ? MAKAN DUIT HARAM ? NGENTOT TIAP HARI ? BAHAHAHHA ORA PANTES BET MUKA-MUKA BOCAH AUTIS**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("p")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**PADA NGAPA BAE SI ? ET DAH MO JADI JAGOAN LU ? LAA BOCAH SI TIAP HARI ADA BAE KELAKUAN NYA!! AUTIS KALI MAH.**",
        reply_to_message_id=ReplyCheck(m),
    )


# @ky.ubot("q")
# async def _(c: nlx, m):
#     if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#         await m.reply("**AKUN LO MO ILANG BANGSAT??**")
#         return
#     await m.reply(
#         "**QONTOL QONTOL, MUKA DEKIL, ITEM, BURIK, BOPAK, RAMBUT LU KEK JEMBUT GA BERATURAN MASIH PEDE LO IDUP?**",
#         reply_to_message_id=ReplyCheck(m),
#     )


@ky.ubot("r")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**RAME AMAT YA, KEREN KALI MAH BEGITU? LAA BOCAH BARU LAHIR KEMAREN BANYAK GAYA. TONG TONG!! EMA LO NYESEL KEK NYA LAHIRIN MAKHLUK KE LU!!**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("s")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**SIAPA ? EMA LU SIAPA ? KAGA MIRIP EMA AMA BABA LU. ANAK BOLEH MUNGUT DI PINGGIR GOT KALI LU!!**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("t")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**TUMAN, BOCAH TUMAN. DIKASIH PANGGUNA LANTAS BAE BERTINGKAH. MENDING CAKEP LA MUKA KAYA PANTAT PENGAMEN KAGA MANDI 1 MINGGU**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("u")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**UNTUNG GW BUKAN TEMEN NYA DIA, BUNUH BAE MAKHLUK KAYA GINI. EMANYA JUGA IKHLAS KALI DIA MATI!!**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("v")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**APA KONTOL?**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("w")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**WAH BAJINGAN INI LAMA LAMA KAYA JEMBUT, GA BENER BENTUKNYA!!**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("x")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**DIEM MEMEG, MUKA JERAWATN BANYAK BACOT LU!!**",
        reply_to_message_id=ReplyCheck(m),
    )


@ky.ubot("z")
async def _(c: nlx, m):
    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
        return
    await m.reply(
        "**DIEM BANGSAT, BACOT MULU DARI KEMAREN. JADI BEBAN DOANG BELAGU LU. GAWE TONG GAWE, LAA PUNYA AKAL SI DIDIEMIN KAGA DIPAKE**",
        reply_to_message_id=ReplyCheck(m),
    )
